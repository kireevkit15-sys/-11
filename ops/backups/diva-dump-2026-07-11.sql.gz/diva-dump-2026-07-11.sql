--
-- PostgreSQL database dump
--

\restrict WsXciRgaLcv7SoeAvY0eWQNoAZL5BbSnzpu4oB8fSR396Bjg3aHbq54dmfXxPnn

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'admin'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    require_password_change boolean DEFAULT true NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: announcement_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcement_messages (
    id integer NOT NULL,
    key character varying(50),
    message text,
    badge character varying(50),
    hue integer DEFAULT 200,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    cta_text character varying(100),
    href character varying(255)
);


--
-- Name: announcement_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcement_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcement_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcement_messages_id_seq OWNED BY public.announcement_messages.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    role character varying(255),
    company character varying(255),
    bio text,
    skills jsonb,
    github_link character varying(255),
    portfolio_link character varying(255),
    vk_link character varying(255),
    telegram_link character varying(255),
    contact character varying(255),
    badge character varying(255),
    hue integer,
    available boolean,
    featured boolean,
    category character varying(255),
    sort_order integer,
    key character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    content text,
    title text
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    body text,
    cover_url text,
    category text DEFAULT 'Прочее'::text NOT NULL,
    reading_minutes integer DEFAULT 5 NOT NULL,
    seo_title text,
    seo_description text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    payload jsonb,
    ip text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: calculator_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calculator_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    inputs jsonb NOT NULL,
    result_price integer,
    lead_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE calculator_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.calculator_logs IS 'Лог использования калькулятора стоимости: входные параметры, результат, связь с лидом.';


--
-- Name: case_studies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_studies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    client_name text,
    client_logo_url text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    task text,
    solution text,
    result text,
    quote text,
    quote_author text,
    period text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    next_contact_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: consult_modal_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consult_modal_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    title character varying(255),
    subtitle text,
    stats jsonb DEFAULT '[]'::jsonb,
    times jsonb DEFAULT '[]'::jsonb,
    contacts jsonb DEFAULT '[]'::jsonb,
    cta_text character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: consult_modal_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consult_modal_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consult_modal_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consult_modal_configs_id_seq OWNED BY public.consult_modal_configs.id;


--
-- Name: district_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.district_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    short_name text NOT NULL,
    name text NOT NULL,
    capital text,
    clients integer DEFAULT 0 NOT NULL,
    color text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faqs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    category text DEFAULT 'Бухгалтерия'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: footer_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.footer_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    email character varying(255),
    phones jsonb DEFAULT '[]'::jsonb,
    address text,
    legal_info text,
    work_hours character varying(100),
    nav_columns jsonb DEFAULT '[]'::jsonb,
    social_links jsonb DEFAULT '[]'::jsonb,
    copyright character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: footer_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.footer_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: footer_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.footer_configs_id_seq OWNED BY public.footer_configs.id;


--
-- Name: frontend_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frontend_sections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    page text DEFAULT 'home'::text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fsi_deadline_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fsi_deadline_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    telegram_chat_id bigint NOT NULL,
    grant_type text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE fsi_deadline_subscriptions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.fsi_deadline_subscriptions IS 'Подписки пользователей Telegram-бота на уведомления о дедлайнах грантов ФСИ.';


--
-- Name: fsi_deadlines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fsi_deadlines (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    description text,
    deadline_date date,
    grant_type character varying(255),
    stage character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    sort_order integer DEFAULT 0
);


--
-- Name: fsi_deadlines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fsi_deadlines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fsi_deadlines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fsi_deadlines_id_seq OWNED BY public.fsi_deadlines.id;


--
-- Name: glossary_terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.glossary_terms (
    id integer NOT NULL,
    document_id character varying(255),
    term character varying(255),
    slug character varying(255),
    definition text,
    category character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    sort_order integer DEFAULT 0
);


--
-- Name: glossary_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.glossary_terms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: glossary_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.glossary_terms_id_seq OWNED BY public.glossary_terms.id;


--
-- Name: hero_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    headline text,
    subheadline text,
    cta_text character varying(100),
    badges jsonb DEFAULT '[]'::jsonb,
    stat_number character varying(50),
    stat_label character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: hero_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hero_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hero_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hero_configs_id_seq OWNED BY public.hero_configs.id;


--
-- Name: lead_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid NOT NULL,
    text text NOT NULL,
    author text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    contact text NOT NULL,
    source text,
    page text,
    utm jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    interaction_at timestamp with time zone,
    notified boolean DEFAULT false NOT NULL,
    CONSTRAINT leads_status_check CHECK ((status = ANY (ARRAY['new'::text, 'in_progress'::text, 'spam'::text, 'converted'::text, 'lost'::text])))
);


--
-- Name: TABLE leads; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.leads IS 'Заявки с форм сайта: контактные формы, обратный звонок, лид-магниты.';


--
-- Name: navigation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.navigation_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    label text NOT NULL,
    href text NOT NULL,
    type text DEFAULT 'nav'::text NOT NULL,
    icon text,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: page_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_key text NOT NULL,
    version integer NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_tag_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partner_tag_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    tags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: partner_tag_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.partner_tag_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partner_tag_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.partner_tag_configs_id_seq OWNED BY public.partner_tag_configs.id;


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    company text,
    bio text,
    skills jsonb DEFAULT '[]'::jsonb NOT NULL,
    github_link text,
    portfolio_link text,
    vk_link text,
    telegram_link text,
    contact text,
    badge text DEFAULT 'team'::text NOT NULL,
    hue integer DEFAULT 240 NOT NULL,
    available boolean DEFAULT true NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    category text DEFAULT 'fullstack'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_url text,
    logo_url text
);


--
-- Name: region_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.region_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    blurbs jsonb DEFAULT '{}'::jsonb,
    region_counts jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: region_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.region_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: region_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.region_configs_id_seq OWNED BY public.region_configs.id;


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reminders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid NOT NULL,
    chat_id text NOT NULL,
    message_id integer NOT NULL,
    fire_at timestamp with time zone NOT NULL,
    sent boolean DEFAULT false NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    author_name text NOT NULL,
    author_project text,
    text text NOT NULL,
    source text DEFAULT 'Email'::text NOT NULL,
    source_url text,
    rating integer DEFAULT 5 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    tax_system text DEFAULT 'УСН-Д'::text NOT NULL,
    base_price integer,
    includes jsonb DEFAULT '[]'::jsonb NOT NULL,
    target_audience text,
    is_highlighted boolean DEFAULT false NOT NULL,
    key text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    "group" text DEFAULT 'general'::text NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_statistics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_statistics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value integer NOT NULL,
    suffix text,
    label text NOT NULL,
    caption text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: social_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    label text NOT NULL,
    href text NOT NULL,
    action_text text,
    icon_color text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscribers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text,
    telegram_username text,
    source text,
    subscribed_at timestamp with time zone DEFAULT now(),
    unsubscribed_at timestamp with time zone
);


--
-- Name: TABLE subscribers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.subscribers IS 'Подписчики рассылки: email и/или Telegram-аккаунты.';


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    full_name text NOT NULL,
    "position" text NOT NULL,
    photo_url text,
    bio text,
    education text,
    years_experience integer,
    specialization text,
    quote text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_founder boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: trust_pillars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trust_pillars (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    number text NOT NULL,
    title text NOT NULL,
    content text,
    quote text,
    hue integer DEFAULT 270 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: trust_strip_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trust_strip_configs (
    id integer NOT NULL,
    key character varying(50) DEFAULT 'main'::character varying,
    configs jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: trust_strip_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trust_strip_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trust_strip_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trust_strip_configs_id_seq OWNED BY public.trust_strip_configs.id;


--
-- Name: videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.videos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    video_id text NOT NULL,
    platform text DEFAULT 'youtube'::text NOT NULL,
    description text,
    views integer DEFAULT 0 NOT NULL,
    duration text,
    thumbnail_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id character varying(255),
    locale character varying(255),
    published_at character varying(255)
);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: announcement_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_messages ALTER COLUMN id SET DEFAULT nextval('public.announcement_messages_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: consult_modal_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_modal_configs ALTER COLUMN id SET DEFAULT nextval('public.consult_modal_configs_id_seq'::regclass);


--
-- Name: footer_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footer_configs ALTER COLUMN id SET DEFAULT nextval('public.footer_configs_id_seq'::regclass);


--
-- Name: fsi_deadlines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fsi_deadlines ALTER COLUMN id SET DEFAULT nextval('public.fsi_deadlines_id_seq'::regclass);


--
-- Name: glossary_terms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.glossary_terms ALTER COLUMN id SET DEFAULT nextval('public.glossary_terms_id_seq'::regclass);


--
-- Name: hero_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_configs ALTER COLUMN id SET DEFAULT nextval('public.hero_configs_id_seq'::regclass);


--
-- Name: partner_tag_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_tag_configs ALTER COLUMN id SET DEFAULT nextval('public.partner_tag_configs_id_seq'::regclass);


--
-- Name: region_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_configs ALTER COLUMN id SET DEFAULT nextval('public.region_configs_id_seq'::regclass);


--
-- Name: trust_strip_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trust_strip_configs ALTER COLUMN id SET DEFAULT nextval('public.trust_strip_configs_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	ed532244685a3066026c0ef5556757a822f0427901777f5f44f796f8497ba8e9	1781627322137
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_users (id, email, password_hash, name, role, created_at, updated_at, require_password_change, document_id, locale, published_at) FROM stdin;
07500bcd-0ecb-4867-9f97-db39f99bce0b	admin@diva.ru	$argon2id$v=19$m=19456,t=2,p=1$04ibi9dc8VUg8TAQfFLADA$vLAiyzcF0smwG+3czZUeMZophqchrOlapf+Bqu/puy0	Administrator	admin	2026-06-13 13:38:13.97673+00	2026-07-11 20:04:13.011+00	f	pcq7imu1dir2658in32aa3cb	\N	2026-06-18T10:00:23.485+00:00
\.


--
-- Data for Name: announcement_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcement_messages (id, key, message, badge, hue, available, sort_order, created_at, updated_at, cta_text, href) FROM stdin;
1	checklist	Чек-лист грантополучателя ФСИ + календарь дедлайнов 2026	\N	200	t	0	2026-06-15 18:30:12.670497	2026-06-15 18:30:12.670497	Скачать	#lead-magnet
3	consult	Бесплатная консультация — узнайте стоимость за 30 минут	\N	200	t	2	2026-06-15 18:30:12.670497	2026-06-15 18:30:12.670497	Записаться	#consultation
2	stats	5 лет специализации · 780 клиентов · 94% остаются после консультации	\N	200	t	1	2026-06-15 18:30:12.670497	2026-06-15 18:30:12.670497	Все цифры	#trust
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, document_id, name, role, company, bio, skills, github_link, portfolio_link, vk_link, telegram_link, contact, badge, hue, available, featured, category, sort_order, key, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, content, title) FROM stdin;
28	jptar18bsc0i2sserf7x2oze	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	team	240	t	t	Команда	0	syntax-labs-partner	\N	\N	\N	\N	\N	\N	Полный цикл разработки: от MVP до enterprise. Web, mobile, AI, DevOps.	Syntax Labs — ваш партнёр по разработке
29	zx97zh25axou0xbsw01cxp6q	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	sparkle	30	t	f	Акция	1	free-consultation	\N	\N	\N	\N	\N	\N	30 минут с экспертом по бухгалтерии и отчётности ФСИ. Без обязательств.	Бесплатная консультация
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.articles (id, title, slug, excerpt, body, cover_url, category, reading_minutes, seo_title, seo_description, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, entity, entity_id, payload, ip, user_agent, created_at) FROM stdin;
9a55817f-5624-4224-ac97-05871d8d6451	\N	login_failed	admin_users	\N	\N	::1	curl/8.17.0	2026-06-15 17:52:54.008033+00
a209b608-1323-4af3-a470-998cc83fe939	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 17:53:14.700092+00
7d48eec1-ef67-4e0a-97c9-dd26bfecf8c6	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	services	6ac8e1c8-3c4a-4e83-ac2f-fe51b4c5f823	{"slug": "smoke-test-svc", "title": "�����-���� ������", "includes": ["����� 1", "����� 2"], "basePrice": 15000, "sortOrder": 99, "taxSystem": "���-�", "isHighlighted": true}	::1	curl/8.17.0	2026-06-15 17:53:16.314287+00
79f652c6-e1f3-42cb-a631-034b8f5e9a4c	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	services	6ac8e1c8-3c4a-4e83-ac2f-fe51b4c5f823	{"slug": "smoke-test-svc", "title": "���������� ������", "includes": ["������ ����"], "sortOrder": 5, "taxSystem": "���", "updatedAt": "2026-06-15T17:53:17.667Z", "isHighlighted": false}	::1	curl/8.17.0	2026-06-15 17:53:17.677835+00
34fd4577-4989-4c11-81c8-09b209a54f4c	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	services	6ac8e1c8-3c4a-4e83-ac2f-fe51b4c5f823	\N	::1	curl/8.17.0	2026-06-15 17:53:17.807062+00
c716c47f-d4f7-4fbd-b58a-9a10fa606fb2	07500bcd-0ecb-4867-9f97-db39f99bce0b	logout	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 17:53:18.248347+00
47ce4f67-aeec-4067-a161-caaf8335474b	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 18:46:05.037223+00
c0c193ef-8373-49c7-a438-c16d24c56352	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"badges": ["a", "b"], "ctaText": "���", "headline": "���� *������*", "statLabel": "���", "updatedAt": "2026-06-15T18:46:08.835Z", "statNumber": "99%", "subheadline": "���"}	::1	curl/8.17.0	2026-06-15 18:46:08.882423+00
50199228-8cc5-4646-80b3-d4c80e7ba13f	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	footer-configs	1	{"email": "new@diva.ru", "phones": ["+7 000"], "updatedAt": "2026-06-15T18:46:09.054Z", "navColumns": [{"links": [{"href": "#x", "label": "L"}], "title": "����"}]}	::1	curl/8.17.0	2026-06-15 18:46:09.078273+00
a3c02a84-af99-478d-a594-0789b39cbeb6	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.124.2 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-15 21:19:52.361686+00
ea4155d7-6f4c-4f3e-9317-0f91647b4e01	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 21:31:09.287281+00
43b5d0d0-5cf7-46fd-bd60-ebad04b83997	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 21:46:20.785731+00
d5fc867f-65de-4f4c-b655-cc6f1c983f93	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 21:53:55.259505+00
883868e5-ee7a-4527-810a-5fef919df1cd	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 21:54:29.067087+00
adcbfd10-6b62-4124-8969-ced0a39495a8	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 22:01:14.298703+00
2dc14129-cfe0-442c-8f98-664968211875	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	partners	53be74f2-847e-4972-86ab-6d1e7a2d4057	{"hue": 240, "name": "Syntax Labs", "role": "Product Development Team � 8+ ���������", "badge": "team", "skills": [], "logoUrl": "/uploads/49e9e497-eee4-471c-91f3-c2120078450a.png", "category": "fullstack", "featured": false, "available": true, "updatedAt": "2026-06-15T22:01:21.284Z"}	::1	curl/8.17.0	2026-06-15 22:01:21.330131+00
351ec1e8-b7a2-49f4-abd4-276c774a2ee8	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	partners	53be74f2-847e-4972-86ab-6d1e7a2d4057	{"hue": 240, "name": "Syntax Labs", "role": "Product Development Team � 8+ ���������", "badge": "team", "skills": [], "category": "fullstack", "featured": false, "available": true, "updatedAt": "2026-06-15T22:01:21.495Z"}	::1	curl/8.17.0	2026-06-15 22:01:21.521744+00
297a2c2d-4bf2-4ef2-bd90-1b9b1296a29a	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 22:10:30.615714+00
ae456c10-1d43-4032-ae58-f66c0efdfc28	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 22:29:12.430977+00
3c2f65a1-3fac-47e0-a2ae-9449a671d10d	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 22:37:20.446812+00
8b450788-b7b4-4364-bc67-4f5f029c8186	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-15 23:01:49.05014+00
6a06e67f-127a-4738-9dca-ba2828a33c24	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	lead_notes	ced2b2a9-174f-46fa-89fa-153c6cfe01f9	{"text": "��������, ������������ �� �������", "leadId": "02dced5e-9d6e-4d9c-bbf2-b54accce8b1f"}	::1	curl/8.17.0	2026-06-15 23:03:52.066861+00
7bed5140-2f49-4fee-8e77-1a19134d259d	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	leads	a730cb01-79ea-473c-bfe6-6a89b4e48aad	{"status": "converted", "updatedAt": "2026-06-15T23:06:42.771Z"}	::1	curl/8.17.0	2026-06-15 23:06:42.799478+00
a90ab4a5-baf0-4e5e-9a6a-5853e8474831	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-16 16:07:26.994328+00
616e406d-b4aa-4a40-ac15-a109c9d2cecc	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	admin_users	e9fd2128-75e6-472a-a244-5e67f40f1c98	{"name": "��������", "role": "editor", "email": "editor@diva.ru"}	::1	curl/8.17.0	2026-06-16 16:07:31.317532+00
32fc998e-0772-4bbc-b4d1-e43af46f753d	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	admin_users	398f8276-5230-44f3-925f-96f3694f6c68	{"name": "�����������", "role": "viewer", "email": "viewer@diva.ru"}	::1	curl/8.17.0	2026-06-16 16:07:31.520315+00
4e8f659a-cee0-483c-a18b-7d07cc298e3e	\N	login	admin_users	e9fd2128-75e6-472a-a244-5e67f40f1c98	\N	::1	curl/8.17.0	2026-06-16 16:08:02.455767+00
b9cfdf1b-59ba-4b66-9920-536a0901898f	\N	create	faqs	1c3b3ee6-9fc0-4f48-8260-f8c6c5b1525c	{"fields": ["question", "answer", "category"]}	::1	curl/8.17.0	2026-06-16 16:08:02.773323+00
f0df0bd3-b3ad-4bf2-a3cd-bff6a4c376d4	\N	login	admin_users	398f8276-5230-44f3-925f-96f3694f6c68	\N	::1	curl/8.17.0	2026-06-16 16:08:01.893486+00
50712a76-1087-47a9-be23-a3830a43272f	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	curl/8.17.0	2026-06-16 17:14:43.168687+00
b8a7d3d5-8910-4c8b-827a-37768201d158	07500bcd-0ecb-4867-9f97-db39f99bce0b	reorder	services	\N	{"count": 4}	::1	curl/8.17.0	2026-06-16 17:14:57.548206+00
dc48bf8a-895b-4c76-b59d-83306661a0c4	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	2026-06-16 18:53:18.053209+00
4e0ab081-1545-4180-b520-6841f923a315	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 18:53:49.768326+00
6cc048a0-e0fe-458b-beb0-879e3b3219ee	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 18:54:24.990355+00
57924cdd-20c0-420a-b258-3e7231c75842	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	2026-06-16 19:06:31.31839+00
eb8f6042-2016-420e-96fa-ad0dfdfabf68	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 19:07:28.546739+00
a902a449-251c-48bf-90c8-dfb2d93ea8bb	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 19:08:04.617232+00
1954338b-1c7e-4de9-8834-26c0e922028f	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	2026-06-16 19:22:01.436859+00
42f1c7ce-bd3f-4733-ba44-86278fb728c8	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 19:22:39.186993+00
183cb99e-b7b1-4341-bc50-b4f6bbaee795	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	hero-configs	1	{"fields": ["headline", "subheadline", "ctaText", "badges", "statNumber", "statLabel", "updatedAt"]}	::1	node	2026-06-16 19:22:52.959137+00
1701dc93-b67f-4b48-86e7-5a911e7a96f8	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	team-members	fb57f59b-a480-423c-949d-ea77f9fc92b7	{"fields": ["fullName", "position", "photoUrl", "bio", "yearsExperience", "isFounder", "sortOrder", "updatedAt"]}	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.124.2 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-16 19:56:48.499953+00
0a4e9c78-41ea-4691-9cd7-4083b382a152	07500bcd-0ecb-4867-9f97-db39f99bce0b	update	team-members	fb57f59b-a480-423c-949d-ea77f9fc92b7	{"fields": ["fullName", "position", "photoUrl", "bio", "yearsExperience", "isFounder", "sortOrder", "updatedAt"]}	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.124.2 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-16 19:57:45.023491+00
c5546c95-7105-43e6-a7b2-046cec1d1cc7	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	node	2026-06-17 19:40:28.540359+00
d7e62dfb-2dd0-4669-b1d4-f5b81114639f	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::1	node	2026-06-17 19:44:44.526427+00
a4c665f4-6840-483f-add8-9803e9d005ee	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 14:53:48.882377+00
547da56e-a395-4464-ac87-11b31dad4ad7	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	faqs	0dec18ce-88f5-4e1d-bd7a-12e9dae63a07	{"fields": ["question", "answer", "category", "sortOrder"]}	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 14:56:50.693136+00
3990d153-d8d4-4ac4-a832-17a2f270a7e2	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	faqs	0dec18ce-88f5-4e1d-bd7a-12e9dae63a07	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 14:56:53.638429+00
c83ca56c-7b16-43ab-9861-1e82bff3e09b	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 15:01:24.881745+00
22f0b358-1cce-481e-81e0-0cd3c8fcb8a2	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 15:01:57.050421+00
509c4cb2-f74c-47a9-9b64-a64b48ebe9d1	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 15:06:26.581968+00
691ebbc8-4fef-4a12-ab0c-5b24b1d5d4ae	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	admin_users	53e6abb8-fd66-4410-a6fb-8095693c4b63	{"name": "ZZZ Test", "role": "viewer", "email": "zzz-test-delete@example.com"}	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 15:07:35.549171+00
5c6daa94-def3-435a-bf45-e3d853c44f94	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT; Windows NT 10.0; ru-RU) WindowsPowerShell/5.1.26100.8655	2026-06-21 15:14:56.295444+00
f2080582-5f2d-4aba-b7ad-5807572fcbcd	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 16:02:32.017263+00
0e175342-f45b-4c41-b19d-4c38ecd5d8cc	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	admin_users	53e6abb8-fd66-4410-a6fb-8095693c4b63	{"role": "viewer", "email": "zzz-test-delete@example.com"}	::ffff:127.0.0.1	curl/8.17.0	2026-06-21 16:02:34.265957+00
bd56ea6d-d66b-489e-ba23-570ba8130db2	07500bcd-0ecb-4867-9f97-db39f99bce0b	login	admin_users	07500bcd-0ecb-4867-9f97-db39f99bce0b	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:46:18.513493+00
e9cf565a-f1f3-440f-91c4-e84fc449fbfa	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	services	f9848238-fbbf-4df9-80b1-6b9c68bea433	{"fields": ["title", "slug", "taxSystem", "basePrice", "includes", "isHighlighted"]}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:47:44.36169+00
2ba5cd02-fffb-4d37-b224-1c287092ad6c	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	services	f9848238-fbbf-4df9-80b1-6b9c68bea433	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:48:50.36259+00
2d9364be-d1ff-40b0-952e-8e66b357e557	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	services	90b3972c-a603-4c0e-851c-6557cc2ece8a	{"fields": ["title", "slug", "taxSystem", "basePrice", "includes", "isHighlighted"]}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:53:33.390862+00
f6236fe0-8103-4af7-a2bc-49f5f537f821	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	services	90b3972c-a603-4c0e-851c-6557cc2ece8a	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:53:56.639437+00
9a12f343-8fa4-447e-b11d-1bc82ead0807	07500bcd-0ecb-4867-9f97-db39f99bce0b	create	reviews	3ee4f29c-992f-4fa2-991e-a5f48a8ad156	{"fields": ["authorName", "authorProject", "text"]}	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:54:27.841956+00
1166988a-6b1f-479a-9c24-82797c35248f	07500bcd-0ecb-4867-9f97-db39f99bce0b	delete	reviews	3ee4f29c-992f-4fa2-991e-a5f48a8ad156	\N	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.125.1 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36	2026-06-21 16:55:03.389286+00
\.


--
-- Data for Name: calculator_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calculator_logs (id, inputs, result_price, lead_id, created_at) FROM stdin;
\.


--
-- Data for Name: case_studies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_studies (id, title, slug, client_name, client_logo_url, tags, task, solution, result, quote, quote_author, period, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
b7562d65-b438-4e1f-94bd-0381db9e7628	NeuroBio	neurobio	NeuroBio	\N	["Биотех"]	Поставили учёт с нуля, сопроводили этап «Старт-1» ФСИ	\N	4 млн ₽	\N	\N	\N	0	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	qf836sgbilu2vkrsffrsls0h	\N	2026-06-18T10:00:23.252+00:00
a81b5f03-f7b4-4ac4-95db-8256bc715d98	ITStartup	itstartup	ITStartup	\N	["IT-аккредитация"]	Получили IT-аккредитацию, перевели на льготную ставку	\N	0%	\N	\N	\N	1	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	xa2tpxn8avd9i35290seopda	\N	2026-06-18T10:00:23.252+00:00
5edd61fb-19f6-492e-857d-1135c2db5ed4	СтартапТомск	startap-tomsk	СтартапТомск	\N	["ФСИ Старт"]	Подготовили заявку на «Старт-1», прошли экспертизу с первого раза	\N	8 млн ₽	\N	\N	\N	2	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	yw1yq554l9pvisoaltf1ei0l	\N	2026-06-18T10:00:23.252+00:00
e8c87178-8e0f-4807-a64c-8220a83e3aea	УмнаяСистема	umnaya-sistema	УмнаяСистема	\N	["УСН"]	Оптимизировали налоговую нагрузку при переходе с ОСН на УСН	\N	-23%	\N	\N	\N	3	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	utjal97av71ar26bzl2lx3sf	\N	2026-06-18T10:00:23.252+00:00
c6cd1b6e-010f-4485-8b82-17e4a734de9e	ЭкоТех	eko-tekh	ЭкоТех	\N	["Экспорт"]	Настроили валютный контроль для экспортных контрактов	\N	12 стран	\N	\N	\N	4	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	da8uslcq673hu009v0i9nt4m	\N	2026-06-18T10:00:23.252+00:00
bec89b87-e0e5-434d-8837-d676f49fd70c	СтудКвест	stud-kvest	СтудКвест	\N	["Студенческий стартап"]	Оформили документы для программы «Студенческий стартап» ФСИ	\N	500 тыс ₽	\N	\N	\N	5	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	a5w2nqanmvlkg1yb0uzysajw	\N	2026-06-18T10:00:23.252+00:00
c507b00d-d6a7-49db-9679-3924e26e3a12	МедАналитика	med-analitika	МедАналитика	\N	["MedTech"]	Закрыли 2 года бухгалтерии, подготовили отчётность для инвестора	\N	2,4 млн ₽	\N	\N	\N	6	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	gjkercj29ivbx47tvsfpgssg	\N	2026-06-18T10:00:23.252+00:00
d40c5edd-dcb4-428a-9927-ce7951ac45dd	РоботоТех	roboto-tekh	РоботоТех	\N	["Робототехника"]	Сопроводили грант «Развитие-НТИ» от заявки до отчёта	\N	20 млн ₽	\N	\N	\N	7	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	slkla8t2bo432sp4wii0do2s	\N	2026-06-18T10:00:23.252+00:00
a0883c43-fe64-43d8-872b-69c2b586d0c0	БизнесПлюс	biznes-plyus	БизнесПлюс	\N	["ОСН"]	Перевели на ОСН, настроили КУДиР и управленческую отчётность	\N	x3	\N	\N	\N	8	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	zholsfai44380qtgd4pwb7fg	\N	2026-06-18T10:00:23.252+00:00
5392d2ad-5bc4-4d38-9ef6-288770714302	АУСН-Старт	ausn-start	АУСН-Старт	\N	["АУСН"]	Первое сопровождение стартапа на АУСН — от регистрации до отчёта	\N	100%	\N	\N	\N	9	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	j067uzfqtgl1cs1078mcrg6w	\N	2026-06-18T10:00:23.252+00:00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, lead_id, tags, notes, next_contact_at, created_at) FROM stdin;
\.


--
-- Data for Name: consult_modal_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consult_modal_configs (id, key, title, subtitle, stats, times, contacts, cta_text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: district_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.district_stats (id, code, short_name, name, capital, clients, color, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
9e711570-eaf5-4def-ae74-c88e2ffc4251	CFD	ЦФО	Центральный	Москва	114	#A78BFA	0	2026-06-13 13:51:10.860556+00	2026-06-13 13:51:10.860556+00	z3mpvivfxmvm1n971raugc1f	\N	2026-06-18T10:00:23.273+00:00
2d254ac5-7708-449c-88b2-deefe5e5e6cf	NWFO	СЗФО	Северо-Западный	Санкт-Петербург	142	#F472B6	1	2026-06-13 13:51:10.867662+00	2026-06-13 13:51:10.867662+00	ist009qna3ebwwa73no5ku5m	\N	2026-06-18T10:00:23.273+00:00
ddbed953-a1bf-42c0-aae8-e3b750ebe7a1	SFO	ЮФО	Южный	Ростов-на-Дону	45	#FB923C	2	2026-06-13 13:51:10.870759+00	2026-06-13 13:51:10.870759+00	fks01846s7bbsnwfpd192oxq	\N	2026-06-18T10:00:23.273+00:00
2bce3c96-7846-457c-bf8d-aa8d693996fa	NCFD	СКФО	Северо-Кавказский	Ставрополь	22	#FBBF24	3	2026-06-13 13:51:10.87434+00	2026-06-13 13:51:10.87434+00	m26nwkraq3ibzznlyf71k29a	\N	2026-06-18T10:00:23.273+00:00
21bc9112-3e5c-4e08-9e9b-835d669b7ec4	VFD	ПФО	Приволжский	Казань	82	#34D399	4	2026-06-13 13:51:10.878261+00	2026-06-13 13:51:10.878261+00	omk3sblns9fgmkc8hdpb8e3c	\N	2026-06-18T10:00:23.273+00:00
08465a3b-8c1e-4dc1-b1aa-e0c5d63b13a8	UrFO	УрФО	Уральский	Екатеринбург	110	#38BDF8	5	2026-06-13 13:51:10.883016+00	2026-06-13 13:51:10.883016+00	bz92syu2iiavd9j4gawdqugv	\N	2026-06-18T10:00:23.273+00:00
8fa512f4-c778-499f-a182-5141154f2c17	SFD	СФО	Сибирский	Новосибирск	145	#818CF8	6	2026-06-13 13:51:10.886539+00	2026-06-13 13:51:10.886539+00	ldrusxevkadu4v3n2sn8dlfr	\N	2026-06-18T10:00:23.273+00:00
7d2e6064-eb29-4dee-be1e-deab2dc1d9a0	FEFO	ДФО	Дальневосточный	Владивосток	120	#22D3EE	7	2026-06-13 13:51:10.889935+00	2026-06-13 13:51:10.889935+00	x00rztcvdsuvpqtp002sp1yn	\N	2026-06-18T10:00:23.273+00:00
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faqs (id, question, answer, category, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
dbcf2ad1-05d4-4ec8-ad33-0f93158a871d	Сколько стоит обслуживание?	Зависит от системы налогообложения: АУСН — 5 900 ₽/мес, УСН — 7 900 ₽/мес, ОСН — 8 900 ₽/мес. Сопровождение отчётности по «Студенческому стартапу» или «Старт 1» — 35 000 ₽ за весь грант. Полный состав работ — в блоке «Наши услуги» выше.	Цены и оплата	0	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	ovqu37o2hwiozq4lq6owzchc	\N	2026-06-18T10:00:23.292+00:00
cc7df69d-95ad-477d-8997-6c1d0d6d0d2f	Как формируется конечная стоимость?	Тарифы фиксированные — цена зависит только от системы налогообложения и наличия сопровождения ФСИ. Скрытых надбавок нет, состав работ открыт, всё фиксируется в договоре.	Цены и оплата	1	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	ewq18luqo0d9qdkjz4gn2vth	\N	2026-06-18T10:00:23.292+00:00
9d39fe20-2332-4f5f-83aa-483f46245982	Можно ли поменять тариф позже?	Да. Если бизнес растёт и АУСН становится тесно — переводим на УСН или ОСН вместе с переходным периодом. Если, наоборот, обороты упали — опускаемся на упрощённый режим. Перевод оформляется одним обращением.	Цены и оплата	2	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	pjpoi6qrgeu8qt2c6qxdwl7q	\N	2026-06-18T10:00:23.292+00:00
a84694a4-f6b5-46e0-9884-450c9d1c6423	Какие программы ФСИ вы сопровождаете?	Основные программы Фонда содействия инновациям: «Студенческий стартап», «Старт-1», ЦТ, ИИ, СТ. Стоимость сопровождения — 35 000 ₽ за весь грант. Эксперты компании сами были победителями конкурсов ФСИ — знаем процесс изнутри, не по методичкам.	ФСИ	3	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	rrkl4idz7iy4e0fa9q8mkm4b	\N	2026-06-18T10:00:23.292+00:00
0968e6fe-3cb2-4bd6-bc78-c7f0c45c3e92	Когда начинается оплата при работе с грантом?	Оплата стартует со 2-го этапа гранта. На первом этапе деньги нужны на разработку, а не на бухгалтерию. Первый этап — финансовый и промежуточный технический отчёт — сопровождаем до получения транша на 2-й этап.	ФСИ	4	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	pmk3cysg51fzdfs98hc3ct7q	\N	2026-06-18T10:00:23.292+00:00
bd938be2-92ce-48f2-9963-cab24826c7a4	Что если ФСИ не принял отчёт?	Дорабатываем замечания кураторов до полного принятия — это входит в стоимость. За 4 года работы мы сопроводили 780 стартапов: типичные замечания знаем заранее и стараемся их не допускать.	ФСИ	5	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	oil7jqlsjcwm6due660z6yku	\N	2026-06-18T10:00:23.292+00:00
857ed184-2a01-4dc3-ad54-27a9c5395393	С чего начинается сотрудничество?	Бесплатная консультация — разбираем вашу ситуацию, систему налогообложения, этап гранта. Два формата: если есть конкретные вопросы — эксперт разбирает их и даёт прикладные материалы; если вопросов нет — проводим презентацию всего пути на год. После — подписываем договор и принимаем дела.	Бухгалтерия	6	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	zaxg6ssw8j8otz07hxpmtjec	\N	2026-06-18T10:00:23.292+00:00
354e7d29-f0d3-4f28-adfa-eaced507bf8f	Кто будет моим бухгалтером?	Закреплённый личный бухгалтер из команды, не «отдел сопровождения». В команде 12 специалистов: бухгалтеры с опытом от 3 до 26 лет и консультанты по программам ФСИ с профильным опытом от 3 лет. Все эксперты имеют прикладной опыт работы с ФСИ.	Бухгалтерия	7	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	jmpud8ur6c1cn61ck76gdlcp	\N	2026-06-18T10:00:23.292+00:00
64224d96-4744-4636-bc40-079ca05d9b9f	Как с вами связываться?	Телефон +7 996 636-69-71 (Пн–СБ 08:00–18:00 МСК), email diva.consulting.b@gmail.com, Telegram @diva_accounting. Срочные вопросы по дедлайнам ФСИ — в приоритете.	Бухгалтерия	8	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	t4d1ym5iu9763ouxiaswnct1	\N	2026-06-18T10:00:23.292+00:00
d8a9d2fd-cb42-4184-b15c-c2fe940f0b19	Как защищены мои данные?	Работаем по 152-ФЗ «О персональных данных». Документы передаются через защищённый электронный документооборот, доступ к данным компании имеет только закреплённый за вами бухгалтер.	О компании	9	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	y5ln3j0p3vj3w6efps2aagow	\N	2026-06-18T10:00:23.292+00:00
72626e24-0ed0-4bc5-a2b5-578d44f98813	Гарантия по сданным отчётам ФСИ	Отчёт сопровождается до момента полного принятия экспертизой Фонда. Если куратор возвращает с замечаниями — дорабатываем без доплат. Это часть тарифа, а не extra-услуга.	О компании	10	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	zbov6mlh4e7foyew2z3um6fa	\N	2026-06-18T10:00:23.292+00:00
16510fb9-e704-4c70-a56c-9a96459ce5e9	Что если я уйду через месяц?	Договор расторгается одним обращением — без штрафов и удержаний. Передаём все данные, акты и доступы для следующего бухгалтера.	О компании	11	2026-06-15 21:30:50.027011+00	2026-06-15 21:30:50.027011+00	ru55iax8263vhza4ipps14v0	\N	2026-06-18T10:00:23.292+00:00
\.


--
-- Data for Name: footer_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.footer_configs (id, key, email, phones, address, legal_info, work_hours, nav_columns, social_links, copyright, created_at, updated_at) FROM stdin;
1	main	diva.consulting.b@gmail.com	["+7 996 636-69-71", "+7 983 236-16-91"]	Томская обл., д. Барабинка, ул. Советская, д. 2А	© 2026 ООО «ДИВА БУХГАЛТЕРИЯ» · ИНН 7000014616 · ОГРН 1247000001841	Пн–СБ 08:00–18:00 МСК	[{"links": [{"href": "#services", "label": "УСН"}, {"href": "#services", "label": "ОСН"}, {"href": "#services", "label": "АУСН / ПСН"}, {"href": "#services", "label": "Отчётность ФСИ"}, {"href": "#services", "label": "Регистрация ООО"}], "title": "Услуги"}, {"links": [{"href": "#about", "label": "О нас"}, {"href": "#team", "label": "Команда"}, {"href": "#cases", "label": "Кейсы"}, {"href": "#", "label": "Блог"}, {"href": "#contacts", "label": "Контакты"}], "title": "Компания"}, {"links": [{"href": "#privacy", "label": "Политика конфиденциальности"}, {"href": "#consent", "label": "Согласие на обработку ПДн"}, {"href": "#offer", "label": "Публичная оферта"}], "title": "Документы"}]	[]	Сделано с фокусом на ФСИ-гранты	2026-06-15 18:30:12.666273	2026-06-15 18:46:09.054
\.


--
-- Data for Name: frontend_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frontend_sections (id, key, name, description, page, is_enabled, sort_order, config, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fsi_deadline_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fsi_deadline_subscriptions (id, telegram_chat_id, grant_type, created_at) FROM stdin;
\.


--
-- Data for Name: fsi_deadlines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fsi_deadlines (id, document_id, title, description, deadline_date, grant_type, stage, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, sort_order) FROM stdin;
\.


--
-- Data for Name: glossary_terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.glossary_terms (id, document_id, term, slug, definition, category, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, sort_order) FROM stdin;
\.


--
-- Data for Name: hero_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hero_configs (id, key, headline, subheadline, cta_text, badges, stat_number, stat_label, created_at, updated_at) FROM stdin;
1	main	Завязли в отчётах?\nТогда *кто строит*\nкомпанию?	Возьмём бухгалтерию и отчётность по грантам ФСИ. Бесплатная консультация — 30 минут с экспертом. Без обязательств.	Записаться на консультацию	["30 минут", "без обязательств", "ФСИ и налоги"]	94%	остаются	2026-06-15 18:30:12.66059	2026-06-16 19:22:52.938
\.


--
-- Data for Name: lead_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_notes (id, lead_id, text, author, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, name, contact, source, page, utm, status, notes, created_at, updated_at, interaction_at, notified) FROM stdin;
71a7d8c5-83a0-4a42-8ec4-cd3301a7549f	Анна Соколова	+7 916 224-18-90	site	/services	{}	new	\N	2026-06-17 17:33:02.285004+00	2026-06-20 14:06:53.310644+00	\N	t
f3aa286f-7bb6-40fe-b421-d17f5409f7d5	ООО «Технополис»	t.me/technopolis_fin	telegram	/fsi	{}	in_progress	\N	2026-06-16 19:33:02.285004+00	2026-06-20 14:06:54.094715+00	\N	t
bca24d46-c5cc-4e7c-acde-16b3fd723d95	Игорь Лебедев	igor.lebedev@startup.io	site	/cases	{}	converted	\N	2026-06-13 19:33:02.285004+00	2026-06-20 14:06:54.423229+00	\N	t
5ba87b91-5c33-473e-8877-990b54b38068	Мария Зайцева	+7 903 771-05-42	telegram	/	{}	new	\N	2026-06-17 14:33:02.285004+00	2026-06-20 14:06:54.686708+00	\N	t
a875260e-cf94-4f84-9d19-23b63376ac30	Стартап «ГринТех»	greentech@mail.ru	site	/services	{}	in_progress	\N	2026-06-14 19:33:02.285004+00	2026-06-20 14:06:54.931641+00	\N	t
49ab6398-f405-4ae2-bf3d-96e8a6c94fbd	тест	тест	site	/	{"preferred_time": "day"}	spam	\N	2026-06-21 16:56:15.987153+00	2026-06-21 17:02:38.299015+00	\N	t
3c253911-5936-425e-8604-bf5875f73cc7	тест	тест	site	/	{"preferred_time": "evening"}	new	\N	2026-06-21 17:03:14.857018+00	2026-06-21 17:03:15.313355+00	\N	t
\.


--
-- Data for Name: navigation_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.navigation_items (id, label, href, type, icon, description, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
\.


--
-- Data for Name: page_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_versions (id, page_key, version, config, is_published, published_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: partner_tag_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partner_tag_configs (id, key, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partners (id, name, role, company, bio, skills, github_link, portfolio_link, vk_link, telegram_link, contact, badge, hue, available, featured, category, sort_order, created_at, updated_at, photo_url, logo_url) FROM stdin;
53be74f2-847e-4972-86ab-6d1e7a2d4057	Syntax Labs	Product Development Team · 8+ инженеров	Syntax Labs	Полный цикл разработки продуктов: от идеи до продакшена. Web, mobile, AI/ML, DevOps, дизайн-системы. Строим SaaS, финтех, b2b-платформы и Telegram-боты.	[]	https://github.com/syntaxlabs	\N	\N	https://t.me/kitafun	@kitafun	team	240	t	f	fullstack	0	2026-06-13 13:55:19.575576+00	2026-06-15 22:01:21.495+00	\N	/uploads/49e9e497-eee4-471c-91f3-c2120078450a.png
\.


--
-- Data for Name: region_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.region_configs (id, key, blurbs, region_counts, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reminders (id, lead_id, chat_id, message_id, fire_at, sent) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, author_name, author_project, text, source, source_url, rating, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
0405609b-55fe-4935-9fe2-fbe749016b36	Владимир Кудзоев	\N	Хочу оставить отзыв по работе с организацией Дива. Особенно доволен консультацией бухгалтеров и менеджеров, ведением бухгалтерского и налогового учёта, а также помощью с отчётом и сопровождением в ФСИ. Отчёт с фондом полностью закрыт, было множество нюансов, которые мы быстро решали. Спасибо за эффективную работу!	VK	https://vk.com/99vkudzoev	5	0	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	jx4ooxtfz8id41xcsns57ux5	\N	2026-06-18T10:00:23.359+00:00
d9e6fa47-bc01-416a-830f-ea645a2d8425	Эльбрус Тулатов	\N	Хочу поделиться своим опытом работы с компанией Дива — я очень доволен их услугами. С первых дней работы мне было сложно разобраться в некоторых бухгалтерских нюансах, и тогда на помощь пришла Майя. Самый добрый, отзывчивый и надёжный бухгалтер. Без помощи Дивы мне было бы крайне тяжело. Всем рекомендую!	VK	https://vk.com/id188387297	5	1	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	lyjj2u2genz096r5ijo8gwqw	\N	2026-06-18T10:00:23.359+00:00
dca649fa-b1e0-41aa-8087-16b0ba3f061f	Артём Старов	\N	Удалось поработать с «Дивой» в рамках студенческого стартапа — не ожидал такой поддержки. Речь идёт не только про бухгалтерскую поддержку, но и о помощи с сопроводительной документацией. Сделали всё «под ключ». В момент закрытия гранта была паника, но сотрудники «Дива» успокоили и быстро помогли решить проблему.	VK	https://vk.com/artemniceman	5	2	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	pndcmad2s2drkhd2k2jw30ov	\N	2026-06-18T10:00:23.359+00:00
fef49716-a834-4807-9a79-3795455742f4	Наиля Рахимова	\N	В Диве вам ответят молниеносно — и менеджеры, и бухгалтеры. Майя — сотрудник на вес золота. Отвечала ВСЕГДА, будь то утро или поздний вечер. Я находилась заграницей, у меня сломалась ЭЦП, а восстановить дистанционно не получалось. Майя подсказала как договориться с Фондом и сдать отчётность в бумажном виде. Разве кто-то сейчас будет ТАК помогать?	VK	https://vk.com/rakhimova.nailya	5	3	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	a362aulbumne7ygyyl8erjhq	\N	2026-06-18T10:00:23.359+00:00
1787e364-e6d9-4727-9358-e6ddd1e43ff1	Елена Шувалова	\N	Работаю с компанией Дива с момента получения гранта — более года. Могу оставить только хорошие слова обо всех участниках команды. Благодарю за чёткое и своевременное ведение документооборота, отчётности, сдачи всех требуемых документов. Большая благодарность бухгалтеру Марии, специалисту Диане и руководителю Павлу Бантьеву.	VK	https://vk.com/id144336949	5	4	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	xqn1kohwd6tfvttqggpit4g4	\N	2026-06-18T10:00:23.359+00:00
6ede5a52-ae2f-45ab-8bcf-340b092f6a27	Денис Петрухин	\N	Хочу отметить высокий профессионализм менеджера Алины и бухгалтера Майи, которые мгновенно реагировали на запросы. Вся отчётность, подготовка документов и корректировки выполнялись грамотно без задержек. Условия сотрудничества были прозрачны, тарифы — понятными. Рекомендую тем, кто ищет надёжного партнёра в части бухгалтерии стартапов.	VK	https://vk.com/id604671455	5	5	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	mof50vhp2y9nrbzokunjtgrv	\N	2026-06-18T10:00:23.359+00:00
0b5072b7-76bb-4fd3-a7a5-08b0adc000a0	Алиса Давлетбаева	\N	За всё время сотрудничества я чувствовала спокойствие и уверенность в том, что все вопросы закрываются вовремя. Майя не просто отвечала на вопросы, а подробно объясняла все нюансы, заранее предупреждала о важных моментах. Бухгалтерия — это не формальное «ведение отчётности», а реальная поддержка и партнёрство. Именно такой опыт я получила здесь.	VK	https://vk.com/alisa.davletbaeva	5	6	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	pu19z1uvpjv0rnpsyf3a84ty	\N	2026-06-18T10:00:23.359+00:00
c07de4a1-b775-4a37-927b-e608415b246a	Анастасия Гисматуллина	\N	Я начала сотрудничество после победы в студенческом стартапе и с самого начала осталась очень довольна. Специалисты компании всегда были на связи, оперативно помогали решать вопросы и подробно объясняли все нюансы. За всё время сотрудничества у меня не возникло ни единого нарекания — только положительный опыт.	VK	https://vk.com/id147303053	5	7	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	p7t9baeclemlsx52y8ggxgej	\N	2026-06-18T10:00:23.359+00:00
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, title, slug, tax_system, base_price, includes, target_audience, is_highlighted, key, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
d3ae6c25-81b8-4feb-a567-c4fc4b8b055e	Отчёты по грантам ФСИ	otchety-po-grantam-fsi	ФСИ	35000	["Подготовка договора с ФСИ", "Подготовка финансового отчёта", "Оформление технического отчёта", "Разработка бизнес-плана", "Заполнение отчёта о развитии стартапа", "Подготовка карты РИД", "Исправление всех замечаний кураторов"]	Договор с ФСИ, фин.отчёт, тех.отчёт, бизнес-план, карта РИД	f	\N	3	2026-06-13 13:54:57.820268+00	2026-06-15 21:30:50.027011+00	fnw7lgwqhgji97x9vqyk5f4w	\N	2026-06-18T10:00:23.375+00:00
e05ec642-44b3-4f1d-beee-56993fb8ac6e	Бухгалтерия для АУСН	buhgalterskoe-dlya-ausn	АУСН	5900	["Расчёт по страховым взносам", "6-НДФЛ", "Персонифицированные сведения", "Отчёт СЗВ-СТАЖ за 2023 год в составе ЕФС-1", "Отчёт 4-ФСС в составе ЕФС-1", "Отчёт СЗВ-ТД в составе ЕФС-1", "Подготовка документов и отчётов по воинскому учёту", "Статистический отчёт в Росстат", "Отчёт об обработке персональных данных в РКН"]	Страховые взносы, 6-НДФЛ, ЕФС-1, военный учёт, Росстат, РКН	f	\N	0	2026-06-13 13:54:57.811747+00	2026-06-15 21:30:50.027011+00	gyzm9snlfi1hvjo9o8j0ljzi	\N	2026-06-18T10:00:23.375+00:00
31f38b46-34a1-4fec-8f45-72630e227735	Бухгалтерия для УСН	buhgalterskoe-dlya-usn	УСН-Д	7900	["Декларация по УСН", "Бухгалтерская отчётность", "Расчёт по страховым взносам", "6-НДФЛ", "Персонифицированные сведения", "Отчёт СЗВ-СТАЖ за 2023 год в составе ЕФС-1", "Отчёт 4-ФСС в составе ЕФС-1", "Отчёт СЗВ-ТД в составе ЕФС-1", "Подготовка документов и отчётов по воинскому учёту", "Статистический отчёт в Росстат", "Отчёт об обработке персональных данных в РКН"]	Декларация по УСН, бухотчётность, взносы, 6-НДФЛ, ЕФС-1, военный учёт	f	\N	1	2026-06-13 13:54:57.814734+00	2026-06-15 21:30:50.027011+00	z99bghrflafr5yfisrrkb9dn	\N	2026-06-18T10:00:23.375+00:00
8e494ae7-1ef0-4728-a9c4-5778c0357586	Бухгалтерия для ОСН	buhgalterskoe-dlya-osn	ОСН	8900	["Бухгалтерская отчётность", "Декларация по НДС", "Декларация по налогу на прибыль", "Декларация по налогу на имущество", "Расчёт по страховым взносам", "6-НДФЛ", "Персонифицированные сведения", "Отчёт СЗВ-СТАЖ за 2023 год в составе ЕФС-1", "Отчёт 4-ФСС в составе ЕФС-1", "Отчёт СЗВ-ТД в составе ЕФС-1", "Подготовка документов и отчётов по воинскому учёту", "Статистический отчёт в Росстат", "Отчёт об обработке персональных данных в РКН"]	Декларации по НДС, прибыли, имущество, взносы, 6-НДФЛ, ЕФС-1	f	\N	2	2026-06-13 13:54:57.817361+00	2026-06-15 21:30:50.027011+00	m8rra4lqmema8l1mdq814ize	\N	2026-06-18T10:00:23.375+00:00
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, key, value, "group", updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_statistics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_statistics (id, key, value, suffix, label, caption, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
1689c2bf-e4ff-47f8-bacd-a2ae88a8e663	years	5	+	Лет специализации	Работаем со стартапами ФСИ с 2021 года	0	2026-06-13 13:54:57.790479+00	2026-06-13 13:54:57.790479+00	kx4j7vo4qm0p0zb3h6p1beg8	\N	2026-06-18T10:00:23.391+00:00
5748bf71-5278-46b3-a6a4-eb9eca8deafc	grants	127	+	Грантов	Успешно оформлено и защищено	2	2026-06-13 13:54:57.796886+00	2026-06-13 13:54:57.796886+00	kbprdxpb66fedubucoxeen7z	\N	2026-06-18T10:00:23.391+00:00
0ed14f45-d991-4b4f-aa66-0ad61cb2d984	reports	100	%	Успешных отчётов	Без замечаний от налоговой и ФСИ	3	2026-06-13 13:54:57.800414+00	2026-06-13 13:54:57.800414+00	o21613ce8ar9hybczpr57haw	\N	2026-06-18T10:00:23.391+00:00
ccdda0b9-11b7-4a3b-bf15-1057431f0ecf	specialists	12		Специалистов	В штате бухгалтерии и консультантов	4	2026-06-13 13:54:57.803483+00	2026-06-13 13:54:57.803483+00	orcwddsokaj3qeu163yavjd1	\N	2026-06-18T10:00:23.391+00:00
3e9274ad-5c75-4d7f-a7a6-a607e031ce4b	satisfaction	98	%	Довольных клиентов	Рекомендуют коллегам и партнёрам	5	2026-06-13 13:54:57.806017+00	2026-06-13 13:54:57.806017+00	t58z6u29p8txnxsnv7xy6xs4	\N	2026-06-18T10:00:23.391+00:00
a3d1011d-f290-411d-a952-2b12bc02f72f	clients	780	+	Клиентов	Технологические компании по всей России	1	2026-06-13 13:54:57.7939+00	2026-06-13 13:54:57.7939+00	r2zovzx6t9rgjfy4zqvunh1k	\N	2026-06-18T10:00:23.391+00:00
\.


--
-- Data for Name: social_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_links (id, platform, label, href, action_text, icon_color, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
11e35653-02b6-4dab-95de-7e42b03d3bed	vk	ВКонтакте	https://vk.com/ac_diva	отзывы и новости	#0077FF	0	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	s6l88ilglj6n24g00sezpnbq	\N	2026-06-18T10:00:23.409+00:00
c002d5fa-37b1-417c-beb5-b330497d5025	telegram	Telegram	https://t.me/diva_accounting	быстрые разборы	#26C4F0	1	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	shwq0rt9mgbhz4r4nlz2gf6k	\N	2026-06-18T10:00:23.409+00:00
e3b1e73d-2464-4b17-b169-bf92c3ccd527	youtube	YouTube	https://youtube.com/channel/UCLDax7nGHf8K1AiP23Z00sA	видео-инструкции	#EF4444	2	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	d5gv12jkk200k57hcng9urc5	\N	2026-06-18T10:00:23.409+00:00
7a5cc080-a6d1-4989-8646-41e34560800d	rutube	RuTube	https://rutube.ru/channel/diva-accounting	записи эфиров	#3B82F6	3	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	q0hlnau3yajf3c93m1iuqart	\N	2026-06-18T10:00:23.409+00:00
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscribers (id, email, telegram_username, source, subscribed_at, unsubscribed_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_members (id, full_name, "position", photo_url, bio, education, years_experience, specialization, quote, sort_order, is_founder, created_at, updated_at, document_id, locale, published_at) FROM stdin;
e7fd3cdc-0782-4c1c-b167-2659e9445e3e	Назимова Майя	Бухгалтер	/team/nazimova-maya.png	Знания по специальности я применяла в работе с финансами всю жизнь, а в профессиональную бухгалтерию пришла после получения удостоверения о повышении квалификации в 2023 году — и сразу в команду «Дива».	Томский политехнический университет, «Бизнес-аналитика и бухгалтерский учёт». Удостоверение о повышении квалификации бухгалтера, 2023.	2	\N	\N	4	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	capxhb9ksw9xw0hl3zftpdqi	\N	2026-06-18T10:00:23.425+00:00
d7af2862-f832-4eec-9dc2-bd89e6d0291c	Ольга Чекаленко	Главный бухгалтер	/team/chekalenko-olga.png	Оперативно решаю сложные задачи, подстраиваюсь под частые изменения законодательства, взаимодействую с контролирующими органами и нахожу ответ на любой, даже очень сложный вопрос. Работа доставляет мне большое удовольствие — приятно видеть, как дело клиента растёт и развивается, и понимать, что в этом есть и мой вклад.	Бакалавр по направлению «Менеджмент» (профиль «Производственный менеджмент»), Национальный исследовательский Томский политехнический университет.	12	Главный бухгалтер с опытом работы 12 лет, из них 5 лет — главным бухгалтером. До этого — бухгалтер по материальным запасам и банку.	\N	1	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	kr03hjq01ggjj3fomxdgvgsz	\N	2026-06-18T10:00:23.425+00:00
6f743ea7-9381-4c01-883a-d0046e7559a5	Петрова Альбина	Бухгалтер · НМА и IT-аккредитация	/team/petrova-albina.png	\N	Алтайский государственный университет. Множество курсов повышения квалификации.	5	Специализация — работа с нематериальными активами. Помимо бухгалтерского и налогового учёта занимается получением IT-аккредитации в стартапах клиентов.	\N	2	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	qjfx430b8wv94hjr6lx7253g	\N	2026-06-18T10:00:23.425+00:00
2c8d8608-6ade-4562-9e64-ea28ea6f35e5	Новикова Ольга	Бухгалтер · оптимизация налогов	/team/novikova-olga.png	Общий стаж 26 лет, профильный — 10 лет.	Московский государственный университет коммерции (1995–2000), управление предприятием. Алтайский государственный технический университет им. И. И. Ползунова (2004), оценка стоимости бизнеса. Государственный университет по землеустройству (2012), оценочная деятельность.	26	Бухгалтер широкого профиля. Помимо серийного бухгалтерского учёта в стартапах, специализируется на оптимизации налоговой нагрузки клиентов.	\N	3	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	k7edux5tvdzelpg4pkt0yix6	\N	2026-06-18T10:00:23.425+00:00
fb57f59b-a480-423c-949d-ea77f9fc92b7	Павел Бантьев	Основатель и директор	/team/bantiev-pavel.jpg	5 лет работы с грантами ФСИ. Знаем каждый этап изнутри.	\N	5	\N	\N	0	t	2026-06-15 22:10:15.013332+00	2026-06-16 19:57:45.006+00	csr9y1rb9cgo98k85wxo7hdp	\N	2026-06-18T10:00:23.425+00:00
414cf107-7205-4843-b0bb-bd2e6d39afa9	Мордвинова Кристина	Бухгалтер · воинский учёт	/team/mordvinova-kristina.png	\N	Бакалавриат — ТУСУР, экономический факультет. Магистратура — Томский экономико-юридический институт, бухгалтерский учёт на предприятии.	8	Бухгалтер широкого профиля. Специализируется на воинском учёте организаций.	\N	7	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	etspl0ine2gms38s9jn9qxj3	\N	2026-06-18T10:00:23.425+00:00
f5acd409-aa52-4cec-870f-e366324911f2	Титаева Валентина	Бухгалтер · финансовая отчётность	/team/titaeva-valentina.png	\N	Бакалавр по направлению «Менеджмент» (профиль «Производственный менеджмент»), Национальный исследовательский Томский политехнический университет. Курсы: бухгалтерский учёт и аудит, финансовый менеджмент.	4	Разработала систему финансовой отчётности по торговым точкам для томского бренда одежды Daisyknit. Принимала участие в разработке системы нормирования труда для сети ресторанов «Дыхание Вока».	Бухгалтер — это не тот, кто считает чужие деньги, а тот, кто не даёт их потерять.	5	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	l4ag0jgn7l11kjgklz3j6bjc	\N	2026-06-18T10:00:23.425+00:00
618521aa-00de-40c5-91b5-04b7a2533d4a	Зубарева Татьяна	Бухгалтер · автоматизация учёта	/team/zubareva-tatiana.png	Люблю обеспечивать порядок в финансах так, чтобы клиенты не отвлекались на рутину. Оказываю помощь в любых ситуациях — не люблю бездействие. Умею оперативно вникать в любые, даже малознакомые области учёта.	Высшее экономическое, ФГАОУ ВУ «Национальный исследовательский Томский политехнический университет». Магистратура по направлению «Цифровая экономика и финансы» (в процессе).	3	\N	Доверяй, но проверяй. А лучше — пересчитай!	6	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	mrjygg65uqiv60vdenbq6gah	\N	2026-06-18T10:00:23.425+00:00
3149c7d3-9cae-4806-ab53-3a450d56703d	Исакова Мария	Бухгалтер · автоматизация	/team/isakova-maria.png	\N	Казанский федеральный университет, управление бизнесом. КФУ, курсы повышения квалификации — бухгалтерский учёт на предприятии.	9	Специализируется на автоматизации процессов бухгалтерского учёта.	\N	8	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	ncp3pzydie3jibycgikmqzg1	\N	2026-06-18T10:00:23.425+00:00
dee76035-f9b6-45c4-a5ec-5f62a84a3f89	Белоусова Диана	Консультант · «Студенческий стартап»	/team/belousova-diana.jpeg	Живу по принципу «лучше попробовать, чем ничего не сделать и пожалеть». Мне нравится бросать себе вызовы и видеть, как растут мои границы возможностей. В работе ставлю качество выше скорости. В свободное время люблю путешествия, музыку и творческие занятия.	ТУСУР, высшее по специальности «Управление качеством». Диплом о профессиональной переподготовке ТУСУР — «Информационная безопасность. Техническая защита конфиденциальной информации». Удостоверение о повышении квалификации БГТУ ВОЕНМЕХ — «Технологическое предпринимательство и бизнес-планирование».	4	\N	Качество важнее спешки.	9	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	jdsngl8n2h495p9maqjos3l3	\N	2026-06-18T10:00:23.425+00:00
e6e45320-ea42-48e7-869e-37795d6fcd01	Мазюк Алина	Консультант · «Студенческий стартап»	/team/mazyuk-alina.jpeg	По образованию — психолог. Последние 5 лет оказываю помощь в подготовке отчётности по грантам ФСИ. Мне интересна работа, связанная с общением, расширением круга контактов среди творческих и неординарных людей, и участие в проектах, которые сами по себе — нестандартные и увлекательные.	Психология — НОУ ВО «Московский социально-педагогический институт» и ЧОУ ВО «Восточная экономико-юридическая гуманитарная академия». Повышение квалификации в ТУСУР («Защита персональных данных», «Система ДПО организации») и СГТУ им. Гагарина («Технологии продвижения в социальных цифровых медиа»).	15	Общий стаж 15 лет, профильный по работе с ФСИ — 5 лет. 12-летний опыт работы в университете по программам дополнительного образования.	Студенты дают идеи. Фонд даёт деньги. Мы — спокойствие. Работает.	10	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	z831zyko3yo0munan3zyysnn	\N	2026-06-18T10:00:23.425+00:00
d6d670d4-a87a-4ebc-85ee-030ee2e331d1	Золотухина Полина	Консультант · «Старт»	/team/zolotukhina-polina.png	\N	Бакалавриат ФГАОУ ВУ «Национальный исследовательский Томский политехнический университет», направление «Экономика». Магистратура по направлению «Цифровая экономика и финансы».	5	Общий опыт работы 5 лет, профильный по работе с грантами ФСИ — 3 года.	\N	11	f	2026-06-15 22:10:15.013332+00	2026-06-15 22:10:15.013332+00	r0aj6vi5nm5y4c27puv6wjs8	\N	2026-06-18T10:00:23.425+00:00
\.


--
-- Data for Name: trust_pillars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trust_pillars (id, number, title, content, quote, hue, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
9901953c-3ec5-4efb-a162-12247a52bfdb	01	Специализация на ФСИ	Мы единственная бухгалтерия, которая работает исключительно со стартапами ФСИ и знает все требования фонда изнутри.	\N	250	0	2026-06-13 13:54:57.771946+00	2026-06-13 13:54:57.771946+00	gd1j7wkxq22b91kz5blk3pch	\N	2026-06-18T10:00:23.444+00:00
525c7576-7309-4453-aa8d-d2aac9de40fb	02	Личный бухгалтер	Закрепляем за каждым клиентом персонального бухгалтера, который знает ваш проект и всегда на связи.	\N	270	1	2026-06-13 13:54:57.779474+00	2026-06-13 13:54:57.779474+00	pw432hfk4ntlmmpxqsou83s3	\N	2026-06-18T10:00:23.444+00:00
d6495a4a-6bd7-4f47-b8d9-d452235813f5	03	Гарантия результата	Фиксируем стоимость в договоре. Если налоговая найдёт нарушения — покрываем штрафы из своего кармана.	\N	290	2	2026-06-13 13:54:57.782017+00	2026-06-13 13:54:57.782017+00	cbuo26rx0nzk34a6p4ea9vdj	\N	2026-06-18T10:00:23.444+00:00
\.


--
-- Data for Name: trust_strip_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trust_strip_configs (id, key, configs, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.videos (id, title, video_id, platform, description, views, duration, thumbnail_url, sort_order, created_at, updated_at, document_id, locale, published_at) FROM stdin;
1199bf9b-035d-4f56-ace4-61255becbf26	О компании ДИВА — бухгалтерия для стартапов	3vvjytkHV3s	youtube	Приветственное видео от основателя: чем занимается ДИВА и почему мы специализируемся на ФСИ.	1200	0:58	https://i.ytimg.com/vi/3vvjytkHV3s/maxresdefault.jpg	0	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	p5j68z5b719vi460cxv26l6r	\N	2026-06-18T10:00:23.458+00:00
5dbc7e3d-76e8-4351-8358-faf83ce8977c	Все шаги для успешного выполнения студенческого стартапа	8wd_Wjk_GKI	youtube	Пошаговый разбор: от подписания договора с ФСИ до закрытия отчётности.	3400	1:02	https://i.ytimg.com/vi/8wd_Wjk_GKI/maxresdefault.jpg	1	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	icb3m7rq1yh3goo89cajcht7	\N	2026-06-18T10:00:23.458+00:00
71c80efb-e8b6-404d-a055-f89f21987219	Где ещё найти деньги на проект после студенческого стартапа	IhXATjZh-Kg	youtube	Три направления для привлечения финансирования, которые работают на практике.	2800	0:55	https://i.ytimg.com/vi/IhXATjZh-Kg/maxresdefault.jpg	2	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	k33e3s8dm167dz4q53x4ynhx	\N	2026-06-18T10:00:23.458+00:00
f1d97659-17e4-4073-910f-b16047acdb43	Почему с бухгалтером проще, чем с автоматизированными сервисами	dULyMhgdsLo	youtube	Живой бухгалтер снимает риски и берёт на себя ответственность — сервисы этого не делают.	1900	0:52	https://i.ytimg.com/vi/dULyMhgdsLo/maxresdefault.jpg	3	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	jxb1isc85h8j98xeoqadhxs0	\N	2026-06-18T10:00:23.458+00:00
d8307ebe-c44b-4878-b400-6a1c21861058	Что такое воинский учёт организации и как с ним работать	Z3Rlm9J_wSQ	youtube	Разбираем обязанности ООО по воинскому учёту: документы, сроки, ответственность.	2100	0:59	https://i.ytimg.com/vi/Z3Rlm9J_wSQ/maxresdefault.jpg	4	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	ecrtg4otdnwx3zh7ppkhjm5r	\N	2026-06-18T10:00:23.458+00:00
8c8cdcfa-4c81-4644-947b-777acd47ba85	Что такое бизнес-план для студенческого стартапа и из чего он состоит	DGB5BeL9ESk	youtube	Структура бизнес-плана для гранта ФСИ: что проверяют кураторы и как не получить замечания.	2600	1:05	https://i.ytimg.com/vi/DGB5BeL9ESk/maxresdefault.jpg	5	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	rxzr4f01adxr0pdjoisno2d5	\N	2026-06-18T10:00:23.458+00:00
998bb2c7-0e18-4b7b-87fc-967e95ea7e44	Популярные вопросы по работе с ФСИ — отвечает эксперт ДИВА	jFu5iLw1W1A	youtube	Разбираем самые частые вопросы грантополучателей: отчётность, договор, финансирование.	5200	31:48	https://i.ytimg.com/vi/jFu5iLw1W1A/maxresdefault.jpg	6	2026-06-15 21:30:02.175782+00	2026-06-15 21:30:02.175782+00	mrw7r2rfh586fwlawcbo1pgs	\N	2026-06-18T10:00:23.458+00:00
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, true);


--
-- Name: announcement_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcement_messages_id_seq', 3, true);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 29, true);


--
-- Name: consult_modal_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consult_modal_configs_id_seq', 1, false);


--
-- Name: footer_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.footer_configs_id_seq', 1, true);


--
-- Name: fsi_deadlines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fsi_deadlines_id_seq', 1, false);


--
-- Name: glossary_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.glossary_terms_id_seq', 1, false);


--
-- Name: hero_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hero_configs_id_seq', 1, true);


--
-- Name: partner_tag_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partner_tag_configs_id_seq', 1, false);


--
-- Name: region_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.region_configs_id_seq', 1, false);


--
-- Name: trust_strip_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trust_strip_configs_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: announcement_messages announcement_messages_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_messages
    ADD CONSTRAINT announcement_messages_key_key UNIQUE (key);


--
-- Name: announcement_messages announcement_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_messages
    ADD CONSTRAINT announcement_messages_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_key UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: calculator_logs calculator_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculator_logs
    ADD CONSTRAINT calculator_logs_pkey PRIMARY KEY (id);


--
-- Name: case_studies case_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_studies
    ADD CONSTRAINT case_studies_pkey PRIMARY KEY (id);


--
-- Name: case_studies case_studies_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_studies
    ADD CONSTRAINT case_studies_slug_key UNIQUE (slug);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: consult_modal_configs consult_modal_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_modal_configs
    ADD CONSTRAINT consult_modal_configs_key_key UNIQUE (key);


--
-- Name: consult_modal_configs consult_modal_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consult_modal_configs
    ADD CONSTRAINT consult_modal_configs_pkey PRIMARY KEY (id);


--
-- Name: district_stats district_stats_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.district_stats
    ADD CONSTRAINT district_stats_code_key UNIQUE (code);


--
-- Name: district_stats district_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.district_stats
    ADD CONSTRAINT district_stats_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: footer_configs footer_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footer_configs
    ADD CONSTRAINT footer_configs_key_key UNIQUE (key);


--
-- Name: footer_configs footer_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footer_configs
    ADD CONSTRAINT footer_configs_pkey PRIMARY KEY (id);


--
-- Name: frontend_sections frontend_sections_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frontend_sections
    ADD CONSTRAINT frontend_sections_key_unique UNIQUE (key);


--
-- Name: frontend_sections frontend_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frontend_sections
    ADD CONSTRAINT frontend_sections_pkey PRIMARY KEY (id);


--
-- Name: fsi_deadline_subscriptions fsi_deadline_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fsi_deadline_subscriptions
    ADD CONSTRAINT fsi_deadline_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: fsi_deadline_subscriptions fsi_deadline_subscriptions_telegram_chat_id_grant_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fsi_deadline_subscriptions
    ADD CONSTRAINT fsi_deadline_subscriptions_telegram_chat_id_grant_type_key UNIQUE (telegram_chat_id, grant_type);


--
-- Name: fsi_deadlines fsi_deadlines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fsi_deadlines
    ADD CONSTRAINT fsi_deadlines_pkey PRIMARY KEY (id);


--
-- Name: glossary_terms glossary_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.glossary_terms
    ADD CONSTRAINT glossary_terms_pkey PRIMARY KEY (id);


--
-- Name: hero_configs hero_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_configs
    ADD CONSTRAINT hero_configs_key_key UNIQUE (key);


--
-- Name: hero_configs hero_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_configs
    ADD CONSTRAINT hero_configs_pkey PRIMARY KEY (id);


--
-- Name: lead_notes lead_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: navigation_items navigation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_items
    ADD CONSTRAINT navigation_items_pkey PRIMARY KEY (id);


--
-- Name: page_versions page_versions_page_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_versions
    ADD CONSTRAINT page_versions_page_version_key UNIQUE (page_key, version);


--
-- Name: page_versions page_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_versions
    ADD CONSTRAINT page_versions_pkey PRIMARY KEY (id);


--
-- Name: partner_tag_configs partner_tag_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_tag_configs
    ADD CONSTRAINT partner_tag_configs_key_key UNIQUE (key);


--
-- Name: partner_tag_configs partner_tag_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_tag_configs
    ADD CONSTRAINT partner_tag_configs_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: region_configs region_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_configs
    ADD CONSTRAINT region_configs_key_key UNIQUE (key);


--
-- Name: region_configs region_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_configs
    ADD CONSTRAINT region_configs_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: services services_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_slug_key UNIQUE (slug);


--
-- Name: site_settings site_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_key_unique UNIQUE (key);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: site_statistics site_statistics_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_statistics
    ADD CONSTRAINT site_statistics_key_key UNIQUE (key);


--
-- Name: site_statistics site_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_statistics
    ADD CONSTRAINT site_statistics_pkey PRIMARY KEY (id);


--
-- Name: social_links social_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_links
    ADD CONSTRAINT social_links_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_email_key UNIQUE (email);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_telegram_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_telegram_username_key UNIQUE (telegram_username);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: trust_pillars trust_pillars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trust_pillars
    ADD CONSTRAINT trust_pillars_pkey PRIMARY KEY (id);


--
-- Name: trust_strip_configs trust_strip_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trust_strip_configs
    ADD CONSTRAINT trust_strip_configs_key_key UNIQUE (key);


--
-- Name: trust_strip_configs trust_strip_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trust_strip_configs
    ADD CONSTRAINT trust_strip_configs_pkey PRIMARY KEY (id);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: announcements_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_created_by_id_fk ON public.announcements USING btree (created_by_id);


--
-- Name: announcements_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_documents_idx ON public.announcements USING btree (document_id, locale, published_at);


--
-- Name: announcements_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_updated_by_id_fk ON public.announcements USING btree (updated_by_id);


--
-- Name: fsi_deadlines_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fsi_deadlines_created_by_id_fk ON public.fsi_deadlines USING btree (created_by_id);


--
-- Name: fsi_deadlines_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fsi_deadlines_documents_idx ON public.fsi_deadlines USING btree (document_id, locale, published_at);


--
-- Name: fsi_deadlines_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fsi_deadlines_updated_by_id_fk ON public.fsi_deadlines USING btree (updated_by_id);


--
-- Name: glossary_terms_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX glossary_terms_created_by_id_fk ON public.glossary_terms USING btree (created_by_id);


--
-- Name: glossary_terms_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX glossary_terms_documents_idx ON public.glossary_terms USING btree (document_id, locale, published_at);


--
-- Name: glossary_terms_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX glossary_terms_updated_by_id_fk ON public.glossary_terms USING btree (updated_by_id);


--
-- Name: idx_admin_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_users_email ON public.admin_users USING btree (email);


--
-- Name: idx_announcements_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_announcements_key ON public.announcements USING btree (key);


--
-- Name: idx_announcements_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_announcements_sort_order ON public.announcements USING btree (sort_order);


--
-- Name: idx_articles_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_articles_category ON public.articles USING btree (category);


--
-- Name: idx_articles_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_articles_slug ON public.articles USING btree (slug);


--
-- Name: idx_articles_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_articles_sort_order ON public.articles USING btree (sort_order);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_calculator_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_calculator_logs_created_at ON public.calculator_logs USING btree (created_at DESC);


--
-- Name: idx_case_studies_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_studies_slug ON public.case_studies USING btree (slug);


--
-- Name: idx_case_studies_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_studies_sort_order ON public.case_studies USING btree (sort_order);


--
-- Name: idx_clients_lead_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_lead_id ON public.clients USING btree (lead_id);


--
-- Name: idx_district_stats_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_district_stats_code ON public.district_stats USING btree (code);


--
-- Name: idx_district_stats_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_district_stats_sort_order ON public.district_stats USING btree (sort_order);


--
-- Name: idx_faqs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faqs_category ON public.faqs USING btree (category);


--
-- Name: idx_faqs_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faqs_sort_order ON public.faqs USING btree (sort_order);


--
-- Name: idx_frontend_sections_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frontend_sections_key ON public.frontend_sections USING btree (key);


--
-- Name: idx_frontend_sections_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frontend_sections_page ON public.frontend_sections USING btree (page);


--
-- Name: idx_frontend_sections_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frontend_sections_sort_order ON public.frontend_sections USING btree (sort_order);


--
-- Name: idx_fsi_deadlines_deadline_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fsi_deadlines_deadline_date ON public.fsi_deadlines USING btree (deadline_date);


--
-- Name: idx_fsi_deadlines_grant_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fsi_deadlines_grant_type ON public.fsi_deadlines USING btree (grant_type);


--
-- Name: idx_glossary_terms_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_glossary_terms_sort_order ON public.glossary_terms USING btree (sort_order);


--
-- Name: idx_glossary_terms_term; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_glossary_terms_term ON public.glossary_terms USING btree (term);


--
-- Name: idx_lead_notes_lead_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_notes_lead_id ON public.lead_notes USING btree (lead_id);


--
-- Name: idx_leads_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_created_at ON public.leads USING btree (created_at DESC);


--
-- Name: idx_leads_notified; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_notified ON public.leads USING btree (notified);


--
-- Name: idx_leads_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_status ON public.leads USING btree (status);


--
-- Name: idx_navigation_items_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_navigation_items_sort_order ON public.navigation_items USING btree (sort_order);


--
-- Name: idx_navigation_items_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_navigation_items_type ON public.navigation_items USING btree (type);


--
-- Name: idx_page_versions_is_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_versions_is_published ON public.page_versions USING btree (is_published);


--
-- Name: idx_page_versions_page_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_versions_page_key ON public.page_versions USING btree (page_key);


--
-- Name: idx_page_versions_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_versions_version ON public.page_versions USING btree (version);


--
-- Name: idx_partners_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_partners_category ON public.partners USING btree (category);


--
-- Name: idx_partners_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_partners_sort_order ON public.partners USING btree (sort_order);


--
-- Name: idx_reminders_fire_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reminders_fire_at ON public.reminders USING btree (fire_at);


--
-- Name: idx_reviews_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_sort_order ON public.reviews USING btree (sort_order);


--
-- Name: idx_services_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_services_slug ON public.services USING btree (slug);


--
-- Name: idx_services_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_services_sort_order ON public.services USING btree (sort_order);


--
-- Name: idx_site_settings_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_settings_group ON public.site_settings USING btree ("group");


--
-- Name: idx_site_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_settings_key ON public.site_settings USING btree (key);


--
-- Name: idx_site_statistics_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_statistics_key ON public.site_statistics USING btree (key);


--
-- Name: idx_site_statistics_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_statistics_sort_order ON public.site_statistics USING btree (sort_order);


--
-- Name: idx_social_links_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_links_sort_order ON public.social_links USING btree (sort_order);


--
-- Name: idx_subscribers_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscribers_email ON public.subscribers USING btree (email);


--
-- Name: idx_team_members_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_sort_order ON public.team_members USING btree (sort_order);


--
-- Name: idx_trust_pillars_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trust_pillars_sort_order ON public.trust_pillars USING btree (sort_order);


--
-- Name: idx_videos_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_videos_sort_order ON public.videos USING btree (sort_order);


--
-- Name: leads leads_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER leads_set_updated_at BEFORE UPDATE ON public.leads FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: audit_logs audit_logs_user_id_admin_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_admin_users_id_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: calculator_logs calculator_logs_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculator_logs
    ADD CONSTRAINT calculator_logs_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: calculator_logs calculator_logs_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculator_logs
    ADD CONSTRAINT calculator_logs_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: clients clients_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: frontend_sections frontend_sections_updated_by_admin_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frontend_sections
    ADD CONSTRAINT frontend_sections_updated_by_admin_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: lead_notes lead_notes_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_notes lead_notes_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: page_versions page_versions_created_by_admin_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_versions
    ADD CONSTRAINT page_versions_created_by_admin_users_id_fk FOREIGN KEY (created_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: reminders reminders_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: site_settings site_settings_updated_by_admin_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_updated_by_admin_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict WsXciRgaLcv7SoeAvY0eWQNoAZL5BbSnzpu4oB8fSR396Bjg3aHbq54dmfXxPnn

